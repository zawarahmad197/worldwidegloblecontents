
import React, { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Menu, X, Globe, ChevronDown } from 'lucide-react';
import { BUSINESS_NAME, COUNTRIES } from '../constants';

const Navbar: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [showVisaMenu, setShowVisaMenu] = useState(false);
  const location = useLocation();

  const navLinks = [
    { name: 'Home', path: '/' },
    { name: 'About Us', path: '/about' },
    { name: 'Services', path: '/services' },
    { name: 'Contact Us', path: '/contact' },
    { name: 'Social Kit', path: '/social-kit' },
  ];

  const isActive = (path: string) => location.pathname === path;

  return (
    <nav className="bg-white shadow-md sticky top-0 z-40">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-20">
          <div className="flex items-center">
            <Link to="/" className="flex items-center gap-2 group">
              <Globe className="w-8 h-8 text-blue-600 group-hover:rotate-12 transition-transform" />
              <span className="text-xl md:text-2xl font-bold bg-gradient-to-r from-blue-700 to-blue-500 bg-clip-text text-transparent">
                Worldwide Global
              </span>
            </Link>
          </div>

          {/* Desktop Nav */}
          <div className="hidden md:flex items-center space-x-4 lg:space-x-8">
            {navLinks.map((link) => (
              <Link
                key={link.path}
                to={link.path}
                className={`font-medium transition-colors ${
                  isActive(link.path) ? 'text-blue-600 border-b-2 border-blue-600' : 'text-slate-600 hover:text-blue-600'
                }`}
              >
                {link.name}
              </Link>
            ))}
            
            <div className="relative group">
              <button
                className="flex items-center gap-1 font-medium text-slate-600 hover:text-blue-600 transition-colors py-2"
                onMouseEnter={() => setShowVisaMenu(true)}
              >
                Visa Services <ChevronDown className="w-4 h-4" />
              </button>
              
              <div 
                className={`absolute right-0 mt-0 w-56 bg-white shadow-xl border border-slate-100 rounded-lg py-2 transition-all duration-200 transform ${
                  showVisaMenu ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-2 pointer-events-none'
                }`}
                onMouseLeave={() => setShowVisaMenu(false)}
              >
                {COUNTRIES.map((country) => (
                  <Link
                    key={country.id}
                    to={`/visas/${country.id}`}
                    className="block px-4 py-2 text-sm text-slate-700 hover:bg-blue-50 hover:text-blue-600"
                    onClick={() => setShowVisaMenu(false)}
                  >
                    {country.flag} {country.name}
                  </Link>
                ))}
              </div>
            </div>

            <Link
              to="/contact"
              className="bg-blue-600 text-white px-6 py-2.5 rounded-full font-semibold hover:bg-blue-700 transition-all hover:shadow-lg"
            >
              Apply Now
            </Link>
          </div>

          {/* Mobile menu button */}
          <div className="md:hidden flex items-center">
            <button
              onClick={() => setIsOpen(!isOpen)}
              className="text-slate-600 p-2"
            >
              {isOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Nav */}
      <div className={`md:hidden overflow-hidden transition-all duration-300 ${isOpen ? 'max-h-screen border-t' : 'max-h-0'}`}>
        <div className="px-4 pt-4 pb-6 space-y-2 bg-white">
          {navLinks.map((link) => (
            <Link
              key={link.path}
              to={link.path}
              onClick={() => setIsOpen(false)}
              className={`block px-3 py-2 rounded-md font-medium ${
                isActive(link.path) ? 'bg-blue-50 text-blue-600' : 'text-slate-600 hover:bg-slate-50'
              }`}
            >
              {link.name}
            </Link>
          ))}
          <div className="border-t pt-2 mt-2">
            <p className="px-3 py-2 text-xs font-bold text-slate-400 uppercase tracking-wider">Visa Countries</p>
            {COUNTRIES.map((country) => (
              <Link
                key={country.id}
                to={`/visas/${country.id}`}
                onClick={() => setIsOpen(false)}
                className="block px-3 py-2 text-slate-600 hover:bg-slate-50 rounded-md"
              >
                {country.flag} {country.name}
              </Link>
            ))}
          </div>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
