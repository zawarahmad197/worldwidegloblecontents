
import React from 'react';
import { Link } from 'react-router-dom';
import { Globe, Mail, Phone, MapPin, MessageCircle } from 'lucide-react';
import { BUSINESS_NAME, PHONE, EMAIL, WHATSAPP_LINK, COUNTRIES } from '../constants';

const Footer: React.FC = () => {
  return (
    <footer className="bg-slate-900 text-slate-300">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 md:py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12">
          {/* Brand */}
          <div className="space-y-6">
            <Link to="/" className="flex items-center gap-2">
              <Globe className="w-8 h-8 text-blue-500" />
              <span className="text-xl font-bold text-white tracking-tight">
                Worldwide Global
              </span>
            </Link>
            <p className="text-sm leading-relaxed">
              Leading international travel agency and visa consultancy. We provide professional and transparent services for your global mobility needs.
            </p>
            <div className="flex gap-4">
               {/* Placeholders for Social Icons */}
               <div className="w-8 h-8 rounded-full bg-slate-800 flex items-center justify-center hover:bg-blue-600 transition-colors cursor-pointer">F</div>
               <div className="w-8 h-8 rounded-full bg-slate-800 flex items-center justify-center hover:bg-blue-600 transition-colors cursor-pointer">I</div>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="text-white font-bold mb-6 text-lg">Quick Links</h4>
            <ul className="space-y-4 text-sm">
              <li><Link to="/" className="hover:text-white transition-colors">Home</Link></li>
              <li><Link to="/about" className="hover:text-white transition-colors">About Us</Link></li>
              <li><Link to="/services" className="hover:text-white transition-colors">Services</Link></li>
              <li><Link to="/contact" className="hover:text-white transition-colors">Contact Us</Link></li>
              <li><Link to="/social-kit" className="hover:text-white transition-colors">Social Assets</Link></li>
            </ul>
          </div>

          {/* Popular Visas */}
          <div>
            <h4 className="text-white font-bold mb-6 text-lg">Popular Visas</h4>
            <ul className="space-y-4 text-sm">
              {COUNTRIES.slice(0, 5).map(c => (
                <li key={c.id}>
                  <Link to={`/visas/${c.id}`} className="hover:text-white transition-colors">{c.name}</Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact Info */}
          <div className="space-y-4">
            <h4 className="text-white font-bold mb-6 text-lg">Get in Touch</h4>
            <div className="flex items-start gap-3">
              <Phone className="w-5 h-5 text-blue-500 shrink-0" />
              <span className="text-sm">{PHONE}</span>
            </div>
            <div className="flex items-start gap-3">
              <Mail className="w-5 h-5 text-blue-500 shrink-0" />
              <span className="text-sm">{EMAIL}</span>
            </div>
            <div className="flex items-start gap-3">
              <MessageCircle className="w-5 h-5 text-blue-500 shrink-0" />
              <a href={WHATSAPP_LINK} target="_blank" rel="noreferrer" className="text-sm hover:text-white">Chat on WhatsApp</a>
            </div>
            <p className="text-xs mt-6 text-slate-500">
              Disclaimer: Visa approval depends on the respective embassy or immigration authority.
            </p>
          </div>
        </div>

        <div className="border-t border-slate-800 mt-12 pt-8 text-center text-xs">
          <p>© {new Date().getFullYear()} {BUSINESS_NAME}. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
