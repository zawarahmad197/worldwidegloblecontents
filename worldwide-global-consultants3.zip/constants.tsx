
import React from 'react';
import { 
  Globe, 
  Plane, 
  GraduationCap, 
  Briefcase, 
  FileCheck, 
  CalendarCheck,
  CheckCircle2
} from 'lucide-react';
import { CountryVisaInfo, ServiceItem, SocialContent } from './types';

export const BUSINESS_NAME = "Worldwide Global Consultants";
export const TAGLINE = "Your Trusted Global Visa & Travel Partner";
export const PHONE = "+92 335 3865719";
export const EMAIL = "info@worldwideglobalconsultants.com";
export const WHATSAPP_LINK = "https://wa.me/923353865719";

export const SERVICES: ServiceItem[] = [
  {
    title: "Tourist Visa",
    description: "Hassle-free application for holiday trips and family visits across the globe.",
    icon: <Plane className="w-8 h-8 text-blue-600" />
  },
  {
    title: "Business Visa",
    description: "Expert assistance for corporate travel, conferences, and business meetings.",
    icon: <Briefcase className="w-8 h-8 text-blue-600" />
  },
  {
    title: "Study Visa Guidance",
    description: "Dedicated support for students aspiring to pursue education in top international universities.",
    icon: <GraduationCap className="w-8 h-8 text-blue-600" />
  },
  {
    title: "Document Review",
    description: "Detailed verification and organization of your files to minimize rejection risks.",
    icon: <FileCheck className="w-8 h-8 text-blue-600" />
  },
  {
    title: "Appointment Booking",
    description: "Timely booking of embassy and VFS appointments for your convenience.",
    icon: <CalendarCheck className="w-8 h-8 text-blue-600" />
  }
];

export const COUNTRIES: CountryVisaInfo[] = [
  {
    id: "schengen",
    name: "Schengen Visa",
    flag: "🇪🇺",
    description: "Travel across 27 European countries with a single visa. Perfect for exploring the heart of Europe.",
    visaTypes: ["Tourist (Short-stay)", "Business", "Family/Friend Visit"],
    documents: [
      "Valid Passport (6 months validity)",
      "Passport-sized photographs",
      "Travel Insurance",
      "Flight Reservations & Hotel Proof",
      "Bank Statements (Last 6 months)",
      "Employment Letter / Business Docs"
    ],
    processSteps: [
      "Consultation & Assessment",
      "Document Preparation",
      "Embassy Appointment Booking",
      "Visa Interview/Submission",
      "Visa Collection"
    ],
    processingTime: "15 - 45 Business Days",
    importantNotes: ["Biometrics are mandatory for first-time applicants.", "Approval depends on the respective embassy."]
  },
  {
    id: "australia",
    name: "Australia",
    flag: "🇦🇺",
    description: "A world-class destination for tourism, work, and education with a robust immigration system.",
    visaTypes: ["Visitor Visa (Subclass 600)", "Student Visa (Subclass 500)", "Business Visitor"],
    documents: [
      "Passport Copy",
      "Financial Capacity Proof",
      "National ID / CNIC",
      "Proof of Assets",
      "Tax Returns (Last 3 Years)",
      "Purpose of Visit Statement"
    ],
    processSteps: [
      "Initial Profile Review",
      "Document Submission Online",
      "Biometrics at VFS",
      "Health Assessment (If required)",
      "Visa Outcome Notification"
    ],
    processingTime: "4 - 8 Weeks",
    importantNotes: ["Most Australian visas are grant-based and issued electronically (e-visa)."]
  },
  {
    id: "new-zealand",
    name: "New Zealand",
    flag: "🇳🇿",
    description: "Experience the stunning landscapes and high quality of life in Aotearoa.",
    visaTypes: ["Visitor Visa", "Student Visa", "Work Visa"],
    documents: [
      "Current Passport",
      "Character Certificate (Police Clearance)",
      "Medical Certificate",
      "Financial Support Evidence",
      "Letter of Intent"
    ],
    processSteps: [
      "Identify Visa Type",
      "Gather Supporting Evidence",
      "Online Application Submission",
      "Application Assessment",
      "Visa Grant"
    ],
    processingTime: "6 - 10 Weeks",
    importantNotes: ["New Zealand has strict health and character requirements."]
  },
  {
    id: "singapore",
    name: "Singapore",
    flag: "🇸🇬",
    description: "The gateway to Southeast Asia, offering incredible urban experiences and business opportunities.",
    visaTypes: ["Entry Visa (Level 1 & 2)", "Business Visa", "Study Pass"],
    documents: [
      "Form 14A",
      "Recent Photograph",
      "Passport Bio-data page",
      "Letter of Introduction (LOI)",
      "Hotel & Flight Details"
    ],
    processSteps: [
      "Application Submission via authorized agent",
      "Payment of Fees",
      "Embassy Review",
      "E-Visa Issuance"
    ],
    processingTime: "3 - 7 Business Days",
    importantNotes: ["Singapore is highly efficient in processing electronic visas."]
  },
  {
    id: "germany",
    name: "Germany",
    flag: "🇩🇪",
    description: "Europe's economic powerhouse, offering great opportunities for professionals and students.",
    visaTypes: ["Schengen Visa", "National Visa (D-type)", "Job Seeker Visa"],
    documents: [
      "Standard Schengen Docs",
      "Detailed CV",
      "Academic Credentials",
      "Blocked Account (For Students)",
      "German Language Proficiency (If applicable)"
    ],
    processSteps: [
      "Appointment Booking at German Embassy/VFS",
      "Preparation of Motivation Letter",
      "Submission of Application",
      "Embassy Interview",
      "Visa Issuance"
    ],
    processingTime: "2 - 8 Weeks (Varies by type)",
    importantNotes: ["Strict adherence to document formatting is required for Germany."]
  },
  {
    id: "italy",
    name: "Italy",
    flag: "🇮🇹",
    description: "The cradle of Western civilization, perfect for tourism, fashion, and history enthusiasts.",
    visaTypes: ["Tourist Visa", "Study Visa", "Business Visa"],
    documents: [
      "Valid Passport",
      "Schengen Standard Photos",
      "Travel Itinerary",
      "Financial Proof",
      "Invitation Letter (If visiting family)"
    ],
    processSteps: [
      "Assemble Document Set",
      "Schedule VFS Global Appointment",
      "Personal Submission",
      "Background Check",
      "Visa Delivery"
    ],
    processingTime: "15 - 30 Business Days",
    importantNotes: ["Ensure all translation of local documents is in Italian/English."]
  },
  {
    id: "ireland",
    name: "Ireland",
    flag: "🇮🇪",
    description: "Known for its rich culture, friendly people, and growing tech industry.",
    visaTypes: ["Short Stay 'C' Visa", "Long Stay 'D' Visa", "Student Visa"],
    documents: [
      "Passport & Previous Passports",
      "Summary Application Form",
      "Comprehensive Study/Visit Plan",
      "Financial Stability Evidence",
      "Accommodation Proof"
    ],
    processSteps: [
      "Online AVATS Application",
      "Submission of Documents to Embassy/VFS",
      "Verification Process",
      "Outcome via Mail/Email"
    ],
    processingTime: "8 - 12 Weeks",
    importantNotes: ["Ireland is not part of the Schengen zone; a separate visa is required."]
  },
  {
    id: "poland",
    name: "Poland",
    flag: "🇵🇱",
    description: "A fast-growing EU member state offering unique cultural experiences and work opportunities.",
    visaTypes: ["Schengen Visa", "National Work Visa", "Student Visa"],
    documents: [
      "Passport",
      "Work Permit (For employment visa)",
      "University Admission Letter",
      "Health Insurance",
      "Living Arrangement Proof"
    ],
    processSteps: [
      "Appointment via E-Konsulat",
      "Application Submission",
      "Embassy Verification",
      "Visa Decision"
    ],
    processingTime: "15 - 45 Business Days",
    importantNotes: ["Work visas require a valid Work Permit issued by Polish authorities."]
  },
  {
    id: "luxembourg",
    name: "Luxembourg",
    flag: "🇱🇺",
    description: "The world's richest country per capita, offering exclusive opportunities in finance and tech.",
    visaTypes: ["Schengen Visa", "Long Term Residence", "Professional Visa"],
    documents: [
      "Valid Passport",
      "Criminal Record Extract",
      "Proof of Significant Funds",
      "Schengen Travel Insurance",
      "Accommodation Verification"
    ],
    processSteps: [
      "Consultation",
      "Document Compilation",
      "Submission via Embassy/Consulate",
      "Luxembourg Ministry Approval",
      "Visa Grant"
    ],
    processingTime: "4 - 8 Weeks",
    importantNotes: ["Luxembourg has very specific requirements for professional immigration."]
  }
];

export const SOCIAL_CONTENT: SocialContent = {
  facebook: {
    pageName: "Worldwide Global Consultants",
    bio: "Trusted Visa & Travel Consultants 🌍 Schengen | Australia | New Zealand | Singapore | Germany | Italy | Ireland | Poland | Luxembourg 📲 WhatsApp: +92 335 3865719",
    coverText: "Worldwide Global Consultants - Your Trusted Global Visa & Travel Partner",
    pinnedPost: "Welcome to Worldwide Global Consultants. We provide professional visa & travel consultancy services for Schengen, Australia, New Zealand, Singapore, Germany, Italy, Ireland, Poland & Luxembourg.\n\n📲 WhatsApp: +92 335 3865719\n📧 info@worldwideglobalconsultants.com\n\nVisa approval depends on the respective embassy or immigration authority."
  },
  instagram: {
    bio: "🌍 Worldwide Global Consultants\n✈️ Global Visa & Travel Experts\n🇪🇺 Schengen | 🇦🇺 🇳🇿 🇸🇬\n📲 WhatsApp: +92 335 3865719"
  },
  whatsapp: {
    autoReply: "Hello 👋\nThank you for contacting Worldwide Global Consultants.\nPlease share:\n1️⃣ Country visa\n2️⃣ Visa type\n3️⃣ Your nationality\n\nOur visa expert will contact you shortly.\n🌍 Your Trusted Global Visa & Partner"
  },
  adsPrompt: "Create high-converting Facebook & Instagram ads for a visa & travel consultancy named Worldwide Global Consultants. Objective: Lead Generation & WhatsApp Messages. Target Audience: People interested in international travel, visas, study abroad, tourism. Age: 22–55. Countries to Promote: Schengen, Australia, New Zealand, Singapore. Focus on professionalism and trust.",
  adCopies: [
    {
      title: "Schengen Visa Ad (High Trust)",
      headline: "✈️ Dream of Europe? Get Your Schengen Visa with Experts!",
      primaryText: "Exploring the 27 countries of Europe has never been easier! 🇪🇺 Worldwide Global Consultants provides professional guidance for Schengen Tourist and Business visas.\n\n✅ 99% Success Rate\n✅ Expert Document Review\n✅ Transparent Process\n\nDon't let paperwork stop your dreams. Start your application today!",
      cta: "WhatsApp Now for Free Consultation"
    },
    {
      title: "Australia & New Zealand (Career & Study)",
      headline: "🇦🇺 Start Your New Life in Australia or NZ! 🇳🇿",
      primaryText: "Looking to work, study, or settle in Australia or New Zealand? 🌍 Our certified consultants help you navigate the complex immigration systems of the South Pacific.\n\n🎯 Visitor Visas\n🎓 Study Guidance\n💼 Professional Consultation\n\nTrusted by thousands of successful applicants!",
      cta: "Apply Now via WhatsApp"
    },
    {
      title: "Singapore (Short & Sweet)",
      headline: "🇸🇬 Visit Singapore: Hassle-Free E-Visa Services",
      primaryText: "Planning a trip to the Lion City? 🦁 Get your Singapore visa processed fast and efficiently with Worldwide Global Consultants.\n\n🚀 3-7 Days Processing\n✅ Minimum Documents Required\n📲 Entirely Online Process\n\nPlan your gateway to Asia now!",
      cta: "Chat with an Expert"
    }
  ]
};