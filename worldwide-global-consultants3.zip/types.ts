// Fix: Added missing React import to resolve 'Cannot find namespace React' for React.ReactNode
import React from 'react';

export interface CountryVisaInfo {
  id: string;
  name: string;
  flag: string;
  description: string;
  visaTypes: string[];
  documents: string[];
  processSteps: string[];
  processingTime: string;
  importantNotes: string[];
}

export interface ServiceItem {
  title: string;
  description: string;
  icon: React.ReactNode;
}

export interface AdCopy {
  title: string;
  headline: string;
  primaryText: string;
  cta: string;
}

export interface SocialContent {
  facebook: {
    pageName: string;
    bio: string;
    coverText: string;
    pinnedPost: string;
  };
  instagram: {
    bio: string;
  };
  whatsapp: {
    autoReply: string;
  };
  adsPrompt: string;
  adCopies: AdCopy[];
}