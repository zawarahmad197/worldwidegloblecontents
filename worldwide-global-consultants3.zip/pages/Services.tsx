
import React from 'react';
import { SERVICES } from '../constants';

const Services: React.FC = () => {
  return (
    <div className="py-20 bg-slate-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-20">
          <h4 className="text-blue-600 font-bold uppercase tracking-widest text-sm mb-4">Our Expertise</h4>
          <h1 className="text-4xl md:text-5xl font-heading font-bold text-slate-900 mb-6">Professional Travel Solutions</h1>
          <p className="text-slate-600 text-lg">
            From initial assessment to visa grant, we provide a full range of services to make your international travel dreams a reality.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-10">
          {SERVICES.map((service, i) => (
            <div key={i} className="group bg-white p-10 rounded-3xl shadow-sm border border-slate-100 hover:shadow-xl hover:-translate-y-1 transition-all duration-300">
              <div className="w-16 h-16 bg-blue-50 rounded-2xl flex items-center justify-center mb-8 group-hover:bg-blue-600 transition-colors duration-300">
                <div className="group-hover:text-white transition-colors duration-300">
                  {service.icon}
                </div>
              </div>
              <h3 className="text-2xl font-bold text-slate-900 mb-4">{service.title}</h3>
              <p className="text-slate-600 leading-relaxed text-lg">
                {service.description}
              </p>
              <div className="mt-8 flex items-center gap-2 text-blue-600 font-bold cursor-pointer opacity-0 group-hover:opacity-100 transition-opacity">
                Learn more <span>→</span>
              </div>
            </div>
          ))}
        </div>

        {/* Value Prop */}
        <div className="mt-24 bg-white rounded-3xl p-12 shadow-sm border border-slate-100 flex flex-col md:flex-row items-center gap-12">
          <div className="flex-1">
            <h2 className="text-3xl font-heading font-bold mb-6">Why Choose Our Consultants?</h2>
            <div className="space-y-6">
              {[
                { title: "High Success Rate", text: "Our meticulous document review process leads to fewer rejections." },
                { title: "Expert Knowledge", text: "We stay updated with the latest changes in immigration laws across all major countries." },
                { title: "Personalized Support", text: "Every case is unique, and we treat it with individual attention and care." }
              ].map((item, i) => (
                <div key={i} className="flex gap-4">
                  <div className="shrink-0 w-8 h-8 rounded-full bg-blue-100 flex items-center justify-center text-blue-600 font-bold">{i+1}</div>
                  <div>
                    <h4 className="font-bold text-slate-900">{item.title}</h4>
                    <p className="text-slate-600">{item.text}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
          <div className="w-full md:w-1/3">
            <img 
              src="https://images.unsplash.com/photo-1551836022-d5d88e9218df?auto=format&fit=crop&q=80&w=2070" 
              alt="Consultation session" 
              className="rounded-2xl shadow-lg"
            />
          </div>
        </div>
      </div>
    </div>
  );
};

export default Services;
