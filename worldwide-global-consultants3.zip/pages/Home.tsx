
import React from 'react';
import { Link } from 'react-router-dom';
import { CheckCircle2, ShieldCheck, Clock, Users, ArrowRight } from 'lucide-react';
import { BUSINESS_NAME, TAGLINE, WHATSAPP_LINK, COUNTRIES, SERVICES } from '../constants';

const Home: React.FC = () => {
  return (
    <div className="flex flex-col">
      {/* Hero Section */}
      <section className="relative h-[85vh] flex items-center overflow-hidden bg-slate-900">
        <div className="absolute inset-0 z-0">
          <img 
            src="https://images.unsplash.com/photo-1436491865332-7a61a109c053?auto=format&fit=crop&q=80&w=2070" 
            alt="Travel background" 
            className="w-full h-full object-cover opacity-40"
          />
        </div>
        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-white">
          <div className="max-w-2xl animate-fade-in-up">
            <h1 className="text-4xl md:text-6xl font-heading font-bold mb-6 leading-tight">
              {BUSINESS_NAME}
            </h1>
            <p className="text-xl md:text-2xl text-blue-200 mb-8 font-light tracking-wide">
              {TAGLINE}
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <Link 
                to="/contact" 
                className="bg-blue-600 hover:bg-blue-700 text-white px-8 py-4 rounded-full font-bold text-lg text-center transition-all shadow-xl hover:shadow-blue-500/20"
              >
                Apply Now
              </Link>
              <a 
                href={WHATSAPP_LINK}
                target="_blank"
                rel="noreferrer"
                className="bg-white hover:bg-slate-100 text-slate-900 px-8 py-4 rounded-full font-bold text-lg text-center transition-all shadow-xl"
              >
                WhatsApp Us
              </a>
              <Link 
                to="/contact" 
                className="bg-transparent border-2 border-white/50 hover:bg-white/10 text-white px-8 py-4 rounded-full font-bold text-lg text-center transition-all"
              >
                Free Consultation
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Trust Badges */}
      <section className="py-12 bg-white border-b">
        <div className="max-w-7xl mx-auto px-4 grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
          {[
            { icon: <ShieldCheck className="w-8 h-8 text-blue-600 mx-auto mb-2" />, label: "Certified Experts" },
            { icon: <Clock className="w-8 h-8 text-blue-600 mx-auto mb-2" />, label: "Fast Processing" },
            { icon: <Users className="w-8 h-8 text-blue-600 mx-auto mb-2" />, label: "Trusted by 5000+" },
            { icon: <CheckCircle2 className="w-8 h-8 text-blue-600 mx-auto mb-2" />, label: "99% Success Rate" }
          ].map((item, i) => (
            <div key={i} className="flex flex-col items-center">
              {item.icon}
              <span className="font-semibold text-slate-700">{item.label}</span>
            </div>
          ))}
        </div>
      </section>

      {/* Popular Countries */}
      <section className="py-20 px-4 max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-heading font-bold mb-4">Visa Services by Country</h2>
          <p className="text-slate-600 max-w-2xl mx-auto">Select your destination and explore our specialized visa consultancy services designed to ensure your success.</p>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
          {COUNTRIES.map((country) => (
            <Link 
              key={country.id}
              to={`/visas/${country.id}`}
              className="group relative overflow-hidden rounded-2xl bg-white shadow-lg hover:shadow-2xl transition-all duration-500 border border-slate-100"
            >
              <div className="p-8">
                <div className="flex justify-between items-start mb-4">
                  <span className="text-5xl">{country.flag}</span>
                  <ArrowRight className="text-slate-300 group-hover:text-blue-600 transition-colors" />
                </div>
                <h3 className="text-xl font-bold text-slate-900 mb-2">{country.name}</h3>
                <p className="text-slate-600 text-sm line-clamp-2">{country.description}</p>
              </div>
              <div className="bg-blue-600 h-1.5 w-0 group-hover:w-full transition-all duration-500" />
            </Link>
          ))}
        </div>
      </section>

      {/* Services Highlight */}
      <section className="bg-slate-50 py-20 px-4">
        <div className="max-w-7xl mx-auto">
           <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-heading font-bold mb-4">Our Core Services</h2>
            <p className="text-slate-600 max-w-2xl mx-auto">Comprehensive solutions for every step of your international journey.</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {SERVICES.map((service, i) => (
              <div key={i} className="bg-white p-8 rounded-2xl shadow-sm hover:shadow-md transition-shadow">
                <div className="mb-6">{service.icon}</div>
                <h3 className="text-xl font-bold mb-3">{service.title}</h3>
                <p className="text-slate-600 leading-relaxed">{service.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-blue-600 text-white text-center px-4">
        <div className="max-w-3xl mx-auto">
          <h2 className="text-3xl md:text-5xl font-heading font-bold mb-8">Ready to start your global journey?</h2>
          <p className="text-xl text-blue-100 mb-10">Get a free initial consultation with our visa experts today and take the first step towards your destination.</p>
          <Link 
            to="/contact" 
            className="inline-block bg-white text-blue-600 px-10 py-4 rounded-full font-bold text-lg hover:bg-slate-100 transition-colors shadow-2xl"
          >
            Contact an Expert Now
          </Link>
        </div>
      </section>
    </div>
  );
};

export default Home;
