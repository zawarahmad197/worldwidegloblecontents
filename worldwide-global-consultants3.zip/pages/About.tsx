
import React from 'react';
import { ShieldCheck, Target, HeartHandshake } from 'lucide-react';
import { BUSINESS_NAME } from '../constants';

const About: React.FC = () => {
  return (
    <div className="py-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center mb-24">
          <div>
            <h4 className="text-blue-600 font-bold uppercase tracking-widest text-sm mb-4">About Us</h4>
            <h1 className="text-4xl md:text-5xl font-heading font-bold text-slate-900 mb-8 leading-tight">
              Dedicated to Bridging the Gap Between You and Your Global Aspirations
            </h1>
            <div className="space-y-6 text-slate-600 leading-relaxed text-lg">
              <p>
                {BUSINESS_NAME} is a leading travel and visa consultancy firm dedicated to providing comprehensive solutions for international travel. With years of experience and a deep understanding of immigration laws, we help individuals and families navigate the complexities of visa applications.
              </p>
              <p>
                Our team consists of expert visa consultants who are passionate about helping you explore the world. We pride ourselves on our transparent and ethical process, ensuring that every client receives the best possible guidance tailored to their specific needs.
              </p>
            </div>
          </div>
          <div className="relative">
            <div className="aspect-square rounded-2xl overflow-hidden shadow-2xl">
              <img 
                src="https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&q=80&w=1976" 
                alt="Our professional team" 
                className="w-full h-full object-cover"
              />
            </div>
            <div className="absolute -bottom-10 -left-10 bg-blue-600 text-white p-8 rounded-2xl shadow-xl hidden md:block">
              <p className="text-4xl font-bold mb-1">10+</p>
              <p className="text-blue-100 font-medium">Years of Experience</p>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
          <div className="bg-white p-10 rounded-2xl shadow-lg border border-slate-100 text-center">
            <ShieldCheck className="w-12 h-12 text-blue-600 mx-auto mb-6" />
            <h3 className="text-2xl font-bold mb-4">Transparent Process</h3>
            <p className="text-slate-600 leading-relaxed">No hidden fees or unrealistic promises. We provide honest assessments based on current embassy guidelines.</p>
          </div>
          <div className="bg-white p-10 rounded-2xl shadow-lg border border-slate-100 text-center">
            <Target className="w-12 h-12 text-blue-600 mx-auto mb-6" />
            <h3 className="text-2xl font-bold mb-4">Expert Consultants</h3>
            <p className="text-slate-600 leading-relaxed">Our consultants are highly trained in the latest immigration rules for Schengen, Australia, and beyond.</p>
          </div>
          <div className="bg-white p-10 rounded-2xl shadow-lg border border-slate-100 text-center">
            <HeartHandshake className="w-12 h-12 text-blue-600 mx-auto mb-6" />
            <h3 className="text-2xl font-bold mb-4">Ethical Standards</h3>
            <p className="text-slate-600 leading-relaxed">We maintain the highest level of integrity in all our dealings with clients and immigration authorities.</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default About;
