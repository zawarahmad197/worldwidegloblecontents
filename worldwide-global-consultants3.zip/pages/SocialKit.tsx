
import React, { useState } from 'react';
import { Copy, Facebook, Instagram, MessageSquare, CheckCircle, Megaphone, Terminal, ExternalLink } from 'lucide-react';
import { SOCIAL_CONTENT, WHATSAPP_LINK } from '../constants';

const SocialKit: React.FC = () => {
  const [copiedKey, setCopiedKey] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<'profiles' | 'ads'>('profiles');

  const copyToClipboard = (text: string, key: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(key);
    setTimeout(() => setCopiedKey(null), 2000);
  };

  const ContentCard = ({ title, icon, items, contentKey }: { title: string, icon: React.ReactNode, items: { label: string, content: string }[], contentKey: string }) => (
    <div className="bg-white rounded-3xl shadow-sm border border-slate-100 overflow-hidden mb-8">
      <div className="bg-slate-50 px-8 py-6 flex items-center justify-between border-b">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-full bg-white shadow-sm flex items-center justify-center">
            {icon}
          </div>
          <h2 className="text-xl font-bold text-slate-900">{title}</h2>
        </div>
      </div>
      <div className="p-8 space-y-8">
        {items.map((item, i) => (
          <div key={i} className="group relative">
            <div className="flex justify-between items-center mb-2">
              <span className="text-xs font-bold text-slate-400 uppercase tracking-widest">{item.label}</span>
              <button 
                onClick={() => copyToClipboard(item.content, `${contentKey}-${i}`)}
                className="flex items-center gap-1.5 text-blue-600 text-xs font-bold hover:bg-blue-50 px-2 py-1 rounded transition-all"
              >
                {copiedKey === `${contentKey}-${i}` ? (
                  <><CheckCircle className="w-3.5 h-3.5" /> Copied!</>
                ) : (
                  <><Copy className="w-3.5 h-3.5" /> Copy Text</>
                )}
              </button>
            </div>
            <pre className="whitespace-pre-wrap font-sans text-slate-700 bg-slate-50 p-4 rounded-xl border border-slate-100 text-sm leading-relaxed">
              {item.content}
            </pre>
          </div>
        ))}
      </div>
    </div>
  );

  return (
    <div className="py-20 bg-slate-50 min-h-screen">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-heading font-bold text-slate-900 mb-4">Digital Identity & Ads Kit</h1>
          <p className="text-slate-600 text-lg max-w-2xl mx-auto">
            Ready-to-use content for Facebook, Instagram, and WhatsApp Business. 
            Maintain a professional brand voice across all platforms.
          </p>
        </div>

        {/* Tab Switcher */}
        <div className="flex justify-center mb-12">
          <div className="inline-flex bg-white p-1.5 rounded-2xl shadow-sm border border-slate-100">
            <button 
              onClick={() => setActiveTab('profiles')}
              className={`px-8 py-2.5 rounded-xl font-bold transition-all ${activeTab === 'profiles' ? 'bg-blue-600 text-white shadow-md' : 'text-slate-500 hover:text-slate-800'}`}
            >
              Social Profiles
            </button>
            <button 
              onClick={() => setActiveTab('ads')}
              className={`px-8 py-2.5 rounded-xl font-bold transition-all ${activeTab === 'ads' ? 'bg-blue-600 text-white shadow-md' : 'text-slate-500 hover:text-slate-800'}`}
            >
              Ads Manager
            </button>
          </div>
        </div>

        {activeTab === 'profiles' ? (
          <div className="space-y-4">
            <ContentCard 
              title="Facebook Page Content"
              icon={<Facebook className="text-blue-600 w-6 h-6" />}
              contentKey="fb"
              items={[
                { label: "Page Name", content: SOCIAL_CONTENT.facebook.pageName },
                { label: "Short Bio", content: SOCIAL_CONTENT.facebook.bio },
                { label: "Cover Photo Text", content: SOCIAL_CONTENT.facebook.coverText },
                { label: "First Pinned Post", content: SOCIAL_CONTENT.facebook.pinnedPost }
              ]}
            />

            <ContentCard 
              title="Instagram Content"
              icon={<Instagram className="text-pink-600 w-6 h-6" />}
              contentKey="ig"
              items={[
                { label: "Bio Text", content: SOCIAL_CONTENT.instagram.bio }
              ]}
            />

            <ContentCard 
              title="WhatsApp Business"
              icon={<MessageSquare className="text-green-500 w-6 h-6" />}
              contentKey="wa"
              items={[
                { label: "Auto-Reply Message", content: SOCIAL_CONTENT.whatsapp.autoReply }
              ]}
            />
          </div>
        ) : (
          <div className="space-y-12">
            {/* Ads AI Prompt */}
            <div className="bg-slate-900 text-white rounded-3xl p-8 shadow-xl relative overflow-hidden">
               <div className="relative z-10">
                <div className="flex items-center gap-3 mb-6">
                  <Terminal className="text-blue-400 w-6 h-6" />
                  <h2 className="text-2xl font-bold">AI Ads Creation Prompt</h2>
                </div>
                <p className="text-slate-300 text-sm mb-6 leading-relaxed">
                  Copy this prompt into Google Studio AI, Meta Ads AI, or ChatGPT to generate fresh variations of your marketing campaigns.
                </p>
                <div className="bg-slate-800 p-6 rounded-2xl border border-slate-700 relative group">
                  <p className="text-slate-200 font-mono text-sm leading-relaxed mb-4">
                    {SOCIAL_CONTENT.adsPrompt}
                  </p>
                  <button 
                    onClick={() => copyToClipboard(SOCIAL_CONTENT.adsPrompt, 'ads-prompt')}
                    className="flex items-center gap-2 bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg text-xs font-bold transition-all"
                  >
                    {copiedKey === 'ads-prompt' ? <CheckCircle className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                    Copy Prompt
                  </button>
                </div>
              </div>
              <div className="absolute top-0 right-0 w-64 h-64 bg-blue-500/10 rounded-full -translate-y-1/2 translate-x-1/2 blur-3xl"></div>
            </div>

            {/* Pre-written Ad Copies */}
            <div className="space-y-8">
              <div className="flex items-center gap-3 mb-2 px-4">
                <Megaphone className="text-blue-600 w-6 h-6" />
                <h2 className="text-2xl font-bold text-slate-900">High-Converting Ad Copies</h2>
              </div>
              
              {SOCIAL_CONTENT.adCopies.map((ad, idx) => (
                <div key={idx} className="bg-white rounded-3xl shadow-sm border border-slate-100 p-8">
                  <div className="flex justify-between items-start mb-6">
                    <div>
                      <h3 className="text-xl font-bold text-slate-900 mb-1">{ad.title}</h3>
                      <p className="text-xs font-bold text-blue-600 uppercase tracking-widest">Ready to Use</p>
                    </div>
                    <button 
                      onClick={() => copyToClipboard(`${ad.headline}\n\n${ad.primaryText}`, `ad-copy-${idx}`)}
                      className="bg-slate-50 hover:bg-blue-50 text-blue-600 p-3 rounded-2xl transition-all"
                      title="Copy full ad text"
                    >
                      {copiedKey === `ad-copy-${idx}` ? <CheckCircle className="w-5 h-5" /> : <Copy className="w-5 h-5" />}
                    </button>
                  </div>
                  
                  <div className="space-y-6">
                    <div>
                      <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block mb-2">Headline</span>
                      <p className="text-lg font-bold text-slate-900 bg-slate-50 p-3 rounded-xl border-l-4 border-blue-600">{ad.headline}</p>
                    </div>
                    <div>
                      <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block mb-2">Primary Text</span>
                      <p className="text-slate-700 whitespace-pre-wrap leading-relaxed">{ad.primaryText}</p>
                    </div>
                    <div>
                      <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block mb-2">Call to Action</span>
                      <div className="bg-blue-600 text-white font-bold py-3 px-6 rounded-xl inline-flex items-center gap-2">
                        {ad.cta}
                        <ExternalLink className="w-4 h-4" />
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        <div className="mt-16 bg-blue-600 rounded-3xl p-10 text-white text-center">
          <h3 className="text-2xl font-bold mb-4">Brand Consistency is Key</h3>
          <p className="text-blue-100 mb-8 max-w-2xl mx-auto">
            Use these templates and prompts to ensure your consultancy maintains a high level of professionalism and trustworthiness across all digital touchpoints.
          </p>
          <div className="flex flex-wrap justify-center gap-4">
             <div className="bg-white/10 px-4 py-2 rounded-full text-sm font-medium">Professional Copy</div>
             <div className="bg-white/10 px-4 py-2 rounded-full text-sm font-medium">Meta Ads Ready</div>
             <div className="bg-white/10 px-4 py-2 rounded-full text-sm font-medium">High Conversion</div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SocialKit;