
import React from 'react';
import { useParams, Link, Navigate } from 'react-router-dom';
import { 
  CheckCircle2, 
  FileText, 
  Clock, 
  AlertTriangle, 
  ChevronRight,
  Info,
  Calendar
} from 'lucide-react';
import { COUNTRIES, WHATSAPP_LINK } from '../constants';

const VisaDetail: React.FC = () => {
  const { countryId } = useParams<{ countryId: string }>();
  const country = COUNTRIES.find(c => c.id === countryId);

  if (!country) {
    return <Navigate to="/" replace />;
  }

  return (
    <div className="py-12 md:py-20 bg-slate-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="bg-white rounded-3xl p-8 md:p-12 shadow-sm border border-slate-100 mb-12">
          <div className="flex flex-col md:flex-row gap-8 items-center">
            <div className="text-7xl md:text-9xl">{country.flag}</div>
            <div className="flex-1 text-center md:text-left">
              <nav className="flex items-center justify-center md:justify-start gap-2 text-slate-400 text-sm mb-4">
                <Link to="/" className="hover:text-blue-600">Home</Link>
                <ChevronRight className="w-4 h-4" />
                <span className="text-blue-600 font-semibold">{country.name}</span>
              </nav>
              <h1 className="text-4xl md:text-5xl font-heading font-bold text-slate-900 mb-4">{country.name} Visa Services</h1>
              <p className="text-slate-600 text-lg max-w-3xl leading-relaxed">
                {country.description}
              </p>
            </div>
            <div className="shrink-0">
               <a 
                href={WHATSAPP_LINK} 
                target="_blank" 
                rel="noreferrer" 
                className="bg-green-500 hover:bg-green-600 text-white px-8 py-4 rounded-full font-bold shadow-lg transition-all flex items-center gap-2"
              >
                Inquire on WhatsApp
              </a>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-12">
            
            {/* Visa Types */}
            <section className="bg-white rounded-2xl p-8 shadow-sm border border-slate-100">
              <div className="flex items-center gap-3 mb-6">
                <Info className="text-blue-600 w-6 h-6" />
                <h2 className="text-2xl font-bold">Visa Types</h2>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {country.visaTypes.map((type, i) => (
                  <div key={i} className="flex items-center gap-3 p-4 bg-blue-50 rounded-xl text-blue-900 font-medium">
                    <CheckCircle2 className="w-5 h-5 text-blue-600 shrink-0" />
                    {type}
                  </div>
                ))}
              </div>
            </section>

            {/* Required Documents */}
            <section className="bg-white rounded-2xl p-8 shadow-sm border border-slate-100">
              <div className="flex items-center gap-3 mb-6">
                <FileText className="text-blue-600 w-6 h-6" />
                <h2 className="text-2xl font-bold">Required Documents</h2>
              </div>
              <ul className="grid grid-cols-1 md:grid-cols-2 gap-y-4 gap-x-8">
                {country.documents.map((doc, i) => (
                  <li key={i} className="flex items-start gap-3 text-slate-600">
                    <span className="w-1.5 h-1.5 rounded-full bg-blue-600 mt-2 shrink-0"></span>
                    {doc}
                  </li>
                ))}
              </ul>
            </section>

            {/* Step-by-Step Process */}
            <section className="bg-white rounded-2xl p-8 shadow-sm border border-slate-100">
              <div className="flex items-center gap-3 mb-8">
                <Calendar className="text-blue-600 w-6 h-6" />
                <h2 className="text-2xl font-bold">Step-by-Step Visa Process</h2>
              </div>
              <div className="relative space-y-8 pl-8 border-l-2 border-blue-100">
                {country.processSteps.map((step, i) => (
                  <div key={i} className="relative">
                    <div className="absolute -left-[41px] top-0 w-5 h-5 rounded-full bg-blue-600 border-4 border-white"></div>
                    <div className="bg-slate-50 p-6 rounded-xl">
                      <h4 className="font-bold text-slate-900 mb-1">Step {i + 1}</h4>
                      <p className="text-slate-600">{step}</p>
                    </div>
                  </div>
                ))}
              </div>
            </section>
          </div>

          {/* Sidebar */}
          <div className="space-y-8">
             {/* Processing Time */}
            <div className="bg-blue-600 text-white rounded-2xl p-8 shadow-xl">
              <Clock className="w-10 h-10 mb-6" />
              <h3 className="text-xl font-bold mb-2">Processing Time</h3>
              <p className="text-3xl font-heading font-bold mb-4">{country.processingTime}</p>
              <p className="text-blue-100 text-sm leading-relaxed">
                Note: This is an estimated time. Actual duration may vary based on embassy load and individual application specifics.
              </p>
            </div>

            {/* Important Notes */}
            <div className="bg-white rounded-2xl p-8 shadow-sm border border-slate-100">
              <div className="flex items-center gap-3 mb-6">
                <AlertTriangle className="text-amber-500 w-6 h-6" />
                <h3 className="text-xl font-bold">Important Notes</h3>
              </div>
              <ul className="space-y-4">
                {country.importantNotes.map((note, i) => (
                  <li key={i} className="text-sm text-slate-600 flex gap-3">
                    <span className="shrink-0">•</span>
                    {note}
                  </li>
                ))}
                <li className="text-xs text-slate-400 italic pt-4 border-t">
                  Disclaimer: Visa approval depends on the respective embassy or immigration authority. Worldwide Global Consultants acts as a service provider and does not guarantee visa issuance.
                </li>
              </ul>
            </div>

            {/* Contact Card */}
            <div className="bg-slate-900 text-white rounded-2xl p-8 shadow-sm text-center">
              <h3 className="text-xl font-bold mb-4">Need Personalized Help?</h3>
              <p className="text-slate-400 text-sm mb-6">Talk to our {country.name} visa expert for a customized document list.</p>
              <Link to="/contact" className="block w-full bg-white text-slate-900 font-bold py-3 rounded-lg hover:bg-blue-50 transition-colors">
                Book Consultation
              </Link>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default VisaDetail;
